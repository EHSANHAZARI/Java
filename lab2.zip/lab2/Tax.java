package lab2;

import java.util.Scanner;



public class Tax {
	
	// Ranges
	public static int[][] RangeOf2001= {{27050, 65550,136750,297350 }, {45200, 109250, 166500 ,297350},
            {22600, 54625 , 832650, 148675},{36250, 93650, 151650, 297350}} ;
	
	public static int[][] RangeOf2009= {{8350, 33950 , 82250, 171550, 372950}, {16700, 67900, 137050, 208850 ,372950},
	{8350 , 33950 , 68525 , 104425 ,186475 } , {11950 , 45500, 117450 , 190200 , 372950}};
	
	public static double Rate2001[]= {15 , 27.5 , 30.5 , 35.5 ,39.1};
	public static double Rate2009[]= {10, 15 ,25 , 28 , 33 , 35};
	
	// Constant
	public static final int SINGLE_FILER = 0;
	public static final int MARRIED_JOINTLY_OR_QUALIFYING_WIDOWER= 1;
	public static final int MARRIED_SEPARATELY = 2;
	public static final int HEAD_OF_HOUSEHOLD = 3;
	
	// Variables
	private
	static int filingStatus;	
	static int[][]brackets;
	double [] rates;
	static double taxableIncome;
	
	 // Calculate Tax Of 2009
	 public double getTax2() 
	 {
		 
		double tax = taxableIncome;
	        if (filingStatus == 0) {
				if (taxableIncome < 8350) {
					return (tax * 10) / 100;	
				}
				if (taxableIncome < 33950 ) {
					return (tax * 15) / 100;	
				}
				if (taxableIncome < 82250 ) {
					return (tax * 25) / 100;	
				}				
				if (taxableIncome < 171550 ) {
					return (tax * 28) / 100;	
				}
				if (taxableIncome < 372950 ) {
					return (tax * 33) / 100;	
				}
				if (taxableIncome > 372951 ) {
					return (tax * 35) / 100;	
				}
			}
	        if (filingStatus == 1) {
	        	if (taxableIncome < 16700) {
					return (tax * 10) / 100;	
				}
				if (taxableIncome < 67900 ) {
					return (tax * 15) / 100;	
				}
				if (taxableIncome < 137050 ) {
					return (tax * 25) / 100;	
				}				
				if (taxableIncome < 208850 ) {
					return (tax * 28) / 100;	
				}
				if (taxableIncome < 372950 ) {
					return (tax * 33) / 100;	
				}
				if (taxableIncome > 372951 ) {
					return (tax * 35) / 100;	
				}
			}
	        if (filingStatus == 2) {
	        	if (taxableIncome < 8350) {
					return (tax * 10) / 100;	
				}
				if (taxableIncome < 33950 ) {
					return (tax * 15) / 100;	
				}
				if (taxableIncome < 68525 ) {
					return (tax * 25) / 100;	
				}				
				if (taxableIncome < 104425 ) {
					return (tax * 28) / 100;	
				}
				if (taxableIncome < 186475 ) {
					return (tax * 33) / 100;	
				}
				if (taxableIncome > 186476 ) {
					return (tax * 35) / 100;	
				}
			}	       
	        if (filingStatus == 3) {
	        	if (taxableIncome < 16700) {
					return (tax * 10) / 100;	
				}
				if (taxableIncome < 67900 ) {
					return (tax * 15) / 100;	
				}
				if (taxableIncome < 137050 ) {
					return (tax * 25) / 100;	
				}				
				if (taxableIncome < 208850 ) {
					return (tax * 28) / 100;	
				}
				if (taxableIncome > 372950 ) {
					return (tax * 33) / 100;	
				}
				if (taxableIncome < 372951 ) {
					return (tax * 35) / 100;	
				}
			}	 
			return tax;
	        
	 }
	
	
	 //Calculate Tax of 2001
	 public static double getTax() 
	 {
		 
		double tax = taxableIncome;
	        if (filingStatus == 0) {
				if (taxableIncome < 27050) {
					return (tax * 15) / 100;	
				}
				if (taxableIncome < 65550 ) {
					return (tax * 27.5) / 100;	
				}
				if (taxableIncome < 136750 ) {
					return (tax * 30.5) / 100;	
				}				
				if (taxableIncome < 297350 ) {
					return (tax * 35.5) / 100;	
				}
				if (taxableIncome > 297351 ) {
					return (tax * 39.1) / 100;	
				}
			}
	        if (filingStatus == 1) {
				if (taxableIncome < 45200) {
					return (tax * 15) / 100;	
				}
				if (taxableIncome < 109250 ) {
					return (tax * 27.5) / 100;	
				}
				if (taxableIncome < 166500 ) {
					return (tax * 30.5) / 100;	
				}
				if (taxableIncome < 297350 ) {
					return (tax * 35.5) / 100;	
				}
				if (taxableIncome > 297351 ) {
					return (tax * 39.1) / 100;	
				}
			}
	        if (filingStatus == 2) {
				if (taxableIncome < 22600) {
					return (tax * 15) / 100;	
				}
				if (taxableIncome < 540625 ) {
					return (tax * 27.5) / 100;	
				}
				if (taxableIncome < 83250 ) {
					return (tax * 30.5) / 100;	
				}
				if (taxableIncome < 148675 ) {
					return (tax * 35.5) / 100;	
				}
				if (taxableIncome > 148676 ) {
					return (tax * 39.1) / 100;	
				}
			}	       
	        if (filingStatus == 3) {
				if (taxableIncome < 36250) {
					return (tax * 15) / 100;	
				}
				if (taxableIncome < 93650 ) {
					return (tax * 27.5) / 100;	
				}
				if (taxableIncome < 151650 ) {
					return (tax * 30.5) / 100;	
				}
				if (taxableIncome < 297350 ) {
					return (tax * 35.5) / 100;	
				}
				if (taxableIncome > 297351 ) {
					return (tax * 39.1) / 100;	
				}
			}	 
			return tax;
	        
	 }
	

	 // Getters and Setters
	 public int getFilingStatus() {
		return filingStatus;
	}
	 public static void setFilingStatus(int filing) {
		filingStatus = filing;
	}
	 public int[][] getBrackets() {
		return brackets;
	}
	 public void setBrackets(int[][] brackets) {
		this.brackets = brackets;
	}
	 public double[] getRates() {
		return rates;
	}
	 public void setRates(double[] rates) {
		this.rates = rates;
	}
	 public double getTaxableIncome() {
		return taxableIncome;
	}
	 public static void setTaxableIncome(double taxableIn) {
		taxableIncome = taxableIn;
	}
	 
	 // Constructor With Arguments
	 public Tax(int status, int[][] bracks,double[]rateNew, double taxableIn) {
		filingStatus = status;
		brackets = bracks;
		rates = rateNew;
		taxableIncome = taxableIn;
	}
	
	 // Option of 2
	public static void TaxPrinter() 
	{
		System.out.print("Enter the amount from: ");
		Scanner input = new Scanner(System.in);
		double Initialized= input.nextDouble();
		System.out.print("Enter the amount from: ");
		double Final= input.nextDouble();
		double temp=Initialized;
	
		System.out.println("\n");
		System.out.println("2001 tax tables for taxable income from $"+ Initialized + " to $" + Final);
		System.out.println("-----------------------------------------------------------------");
		System.out.println("TaxableIncome\tSingle  Married Joint \t Married Seperate Head of House" );
		System.out.println("-----------------------------------------------------------------");
		
		for (double i = Initialized;  i <= Final ; i+=1000)
		{
			
			System.out.print(i + "\t\t");
			for(int j = 0; j < 4; j++) 
			{
				Tax tax= new Tax(j,RangeOf2001 ,Rate2001 ,i);
				System.out.print( tax.getTax() +"\t\t");	
			}
			System.out.println();
		}
		System.out.println();
		System.out.println("2009 tax tables for taxable income from $"+ Initialized + " to $" + Final);
		System.out.println("-----------------------------------------------------------------");
		System.out.println("TaxableIncome\tSingle  Married Joint \t Married Seperate Head of House" );
		System.out.println("-----------------------------------------------------------------");	
	
		for (double m = Initialized;  m <= Final ; m+=1000)
		{
			
			System.out.print(m + "\t\t");
			for(int j = 0; j < 4; j++) {
				Tax tax= new Tax(j,RangeOf2009 ,Rate2009 ,m);
				System.out.print( tax.getTax2() +"\t\t");	
			}
			System.out.println();
		}
	
	}
	
		
	
	
	public Tax()
	{
		// TODO Auto-generated constructor stub
	}
	
	public static int menue () {
		int selection = 0;
		Scanner input = new Scanner (System.in);
		
		System.out.println("Choose from these choices");
		System.out.println("1.Computer personal income Tax");
		System.out.println("2.Print the tax tables for taxable incomes(with range)");
		System.out.println("3.Exit");
		
		selection = input.nextInt();
		
		
		return selection;
		
	}

	public static void main(String[] args)
	{
		
		int userChoice;
		
		userChoice = menue();
		
		switch (userChoice) {
		case 1:
			System.out.println("*************************");
			System.out.println("0 - single filer");
			System.out.println("1 - married jointly or qualifying widow(er)");
			System.out.println("2 - married separately");
			System.out.println("3 - head of household");
			
			// Getting Output
			Scanner reader = new Scanner (System.in);
			System.out.println("Enter filing status:");
			int status1 = reader.nextInt();
			setFilingStatus(status1);
			System.out.println("Enter Taxable Income:");
			double status2 = reader.nextDouble();
			setTaxableIncome(status2);
			double FinalTax = getTax();
			//print Tax
			System.out.println("Tax is: "+ FinalTax);
			break;
		case 2:
			TaxPrinter();
			break;
		case 3:
			System.out.println("Bye");
		default:
			break;
		}
		
	}

}
