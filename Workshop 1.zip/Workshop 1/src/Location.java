/*
 Name: Mohammad moein Hazari
 ID: 109830182
 email: mhazari@myseneca.ca
 
 */

import java.util.Scanner;

public class Location {
    
	public static void main(String[] args) {
        
    	// we are going to take an information in from the keyboard
    	Scanner in = new Scanner(System.in);
    	
    	System.out.print("Enter the number of rows and columns in the array: ");
        
    	// Receive the row as an integer
    	int rows = in.nextInt();
        int columns = in.nextInt();
        
        // Make the array with inserted informations
        double[][] Array = new double[rows][columns];
        
        System.out.println("Enter the array:");
        
        // Inserting the numbers in array one by one 
        for (int i = 0; i < Array.length; i++) {
            for (int j = 0; j < Array[i].length; j++) {
                Array[i][j] = in.nextDouble();
            }
        }

        int[] location = LargestLocation(Array);
        
        System.out.printf("The location of the largest element is (%d, %d)%n",
            location[0], location[1]);
    }

    public static int[] LargestLocation(double[][] number) {
        // Set the default location
    	int[] location = new int[]{0, 0};
       	// Set the default number 

    	double largest = number[0][0];
        for (int i = 0; i < number.length; i++) {
        for (int j = 0; j < number[i].length; j++) {
                if (largest < number[i][j]) {
                    largest = number[i][j];
                    location[0] = i;
                    location[1] = j;
                }
            }
        }
        return location;
    }


}