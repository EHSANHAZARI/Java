/*
 Name: Mohammad moein Hazari
 ID: 109830182
 email: mhazari@myseneca.ca
 
 */

public class  Craps{
public static void main(String[] args) {

		
		int dice1;
		int dice2;
       
		// Assigning variable for non-win , non-lose to play again
		int dice3;
        int dice4;
		
        // Choose a number between 1 and 6 
		dice1=(int)(Math.random()*6+1);
		dice2=(int)(Math.random()*6+1);
		int sum = dice1 + dice2;
		

		
		boolean game = true;
		
		
		System.out.println("You rolled " +dice1+ " + " +dice2+ " = " +sum);
		
		//  If the sum is 2, 3, or 12 (called craps), you lose
		if ((sum==2)||(sum==3)||(sum==12)) {
			game = false;
			System.out.println("Better Luck Next Time, You lose\r\n" + 
					"");
		} else
		// Lose
		if ((sum==7)||(sum==11)){
			game = false;
			System.out.println("Congratulations, You Win");
		
		} else System.out.println("point is "+sum);

		
		int Sum2;
		
		// Till game is true and the result is unknown continue to play
		while (game){
			
			Sum2 = dice1+dice2;
			dice3=(int)(Math.random()*6+1);
			dice4=(int)(Math.random()*6+1);
			System.out.println("You rolled "+dice1+" + "+dice2+" = "+Sum2);
			if (Sum2==sum){
				game = false;
				System.out.println("You win");
			} else
			if (Sum2==7){
				game =false;
				System.out.println("You lose");
			} else {
				System.out.println("point is "+sum);
			}
	}
	}
}
